//
//  ColorfulApp.swift
//  Colorful
//
//  Created by Antonio Onorato on 05/04/23.
//

import SwiftUI

@main
struct ColorfulApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
